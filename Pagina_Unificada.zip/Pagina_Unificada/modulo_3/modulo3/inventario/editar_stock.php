<?php
session_start();
if (($_SESSION['modulo_acceso'] ?? '') !== 'modulo3') { header('Location: ../../../index.php'); exit; }

require_once "../../config/conexion.php";

if (!isset($_GET["id"]) || !is_numeric($_GET["id"])) {
    die("ID de videojuego no válido.");
}

$idVideojuego = (int) $_GET["id"];

$sql = "SELECT * FROM videojuegos WHERE id_videojuego = ?";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Error al preparar la consulta: " . $conn->error);
}

$stmt->bind_param("i", $idVideojuego);
$stmt->execute();

$resultado = $stmt->get_result();
$juego = $resultado->fetch_assoc();

if (!$juego) {
    die("El videojuego no existe.");
}

$stmt->close();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Modificar stock | Gamekey Store</title>

    <link rel="stylesheet" href="../../css/estilos.css?v=3">
</head>

<body>

    <header class="encabezado">

        <h1>🎮 GAMEKEY STORE</h1>

        <p>Modificar stock</p>

    </header>

    <main class="contenedor">

        <div class="formulario-contenedor">

            <h2>
                <?php echo htmlspecialchars($juego["titulo"]); ?>
            </h2>

            <p class="texto-secundario">
                Plataforma:
                <?php echo htmlspecialchars($juego["plataforma"]); ?>
            </p>

            <form action="actualizar_stock.php" method="POST">

                <input
                    type="hidden"
                    name="id_videojuego"
                    value="<?php echo $juego["id_videojuego"]; ?>"
                >

                <div class="grupo-formulario">

                    <label for="stock">
                        Nuevo stock
                    </label>

                    <input
                        type="number"
                        id="stock"
                        name="stock"
                        min="0"
                        value="<?php echo $juego["stock"]; ?>"
                        required
                    >

                </div>

                <div class="grupo-formulario">

                    <label for="estado">
                        Estado
                    </label>

                    <select id="estado" name="estado" required>

                        <option
                            value="Disponible"
                            <?php echo $juego["estado"] === "Disponible" ? "selected" : ""; ?>
                        >
                            Disponible
                        </option>

                        <option
                            value="Agotado"
                            <?php echo $juego["estado"] === "Agotado" ? "selected" : ""; ?>
                        >
                            Agotado
                        </option>

                        <option
                            value="Inactivo"
                            <?php echo $juego["estado"] === "Inactivo" ? "selected" : ""; ?>
                        >
                            Inactivo
                        </option>

                    </select>

                </div>

                <div class="acciones-formulario">

                    <button type="submit" class="boton-guardar">
                        Guardar cambios
                    </button>

                    <a href="index.php" class="boton-cancelar">
                        Cancelar
                    </a>

                </div>

            </form>

        </div>

    </main>

</body>

</html>