<?php
session_start();
if (($_SESSION['modulo_acceso'] ?? '') !== 'modulo3') { header('Location: ../../../index.php'); exit; }

require_once "../../config/conexion.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php");
    exit;
}

$idVideojuego = isset($_POST["id_videojuego"])
    ? (int) $_POST["id_videojuego"]
    : 0;

$stock = isset($_POST["stock"])
    ? (int) $_POST["stock"]
    : -1;

$estado = $_POST["estado"] ?? "";

$estadosPermitidos = [
    "Disponible",
    "Agotado",
    "Inactivo"
];

if (
    $idVideojuego <= 0 ||
    $stock < 0 ||
    !in_array($estado, $estadosPermitidos, true)
) {
    die("Los datos enviados no son válidos.");
}

if ($stock === 0 && $estado === "Disponible") {
    $estado = "Agotado";
}

$sql = "
    UPDATE videojuegos
    SET stock = ?, estado = ?
    WHERE id_videojuego = ?
";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Error al preparar la actualización: " . $conn->error);
}

$stmt->bind_param(
    "isi",
    $stock,
    $estado,
    $idVideojuego
);

if (!$stmt->execute()) {
    die("Error al actualizar el inventario: " . $stmt->error);
}

$stmt->close();

header("Location: index.php?actualizado=1");
exit;