<?php
session_start();
if (($_SESSION['modulo_acceso'] ?? '') !== 'modulo3') { header('Location: ../../../index.php'); exit; }

require_once "../../config/conexion.php";

$sql = "SELECT * FROM videojuegos ORDER BY id_videojuego DESC";
$resultado = $conn->query($sql);

if (!$resultado) {
    die("Error al consultar el inventario: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Inventario | Gamekey Store</title>

    <link rel="stylesheet" href="../../css/estilos.css?v=3">
</head>

<body>

    <header class="encabezado">

        <h1>🎮 GAMEKEY STORE</h1>

        <p>Módulo 3 - Inventario de videojuegos</p>

    </header>

    <main class="contenedor">

        <div class="titulo-seccion">

            <div>
                <h2>Inventario</h2>
                <p>Consulta y modifica el stock de los videojuegos.</p>
            </div>

            <a class="boton-volver" href="../dashboard.php">
                Volver al dashboard
            </a>

        </div>

        <div class="tabla-contenedor">

            <table>

                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Videojuego</th>
                        <th>Plataforma</th>
                        <th>Precio</th>
                        <th>Stock</th>
                        <th>Estado</th>
                        <th>Acción</th>
                    </tr>
                </thead>

                <tbody>

                    <?php if ($resultado->num_rows > 0): ?>

                        <?php while ($juego = $resultado->fetch_assoc()): ?>

                            <tr>

                                <td>
                                    <?php echo $juego["id_videojuego"]; ?>
                                </td>

                                <td>
                                    <?php echo htmlspecialchars($juego["titulo"]); ?>
                                </td>

                                <td>
                                    <?php echo htmlspecialchars($juego["plataforma"]); ?>
                                </td>

                                <td>
                                    $<?php echo number_format($juego["precio"], 2); ?>
                                </td>

                                <td>
                                    <?php echo $juego["stock"]; ?>
                                </td>

                                <td>
                                    <span class="estado">
                                        <?php echo htmlspecialchars($juego["estado"]); ?>
                                    </span>
                                </td>

                                <td>
                                    <a
                                        class="boton-editar"
                                        href="editar_stock.php?id=<?php echo $juego["id_videojuego"]; ?>"
                                    >
                                        Modificar stock
                                    </a>
                                </td>

                            </tr>

                        <?php endwhile; ?>

                    <?php else: ?>

                        <tr>
                            <td colspan="7" class="sin-datos">
                                No hay videojuegos registrados.
                            </td>
                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </main>

</body>

</html>