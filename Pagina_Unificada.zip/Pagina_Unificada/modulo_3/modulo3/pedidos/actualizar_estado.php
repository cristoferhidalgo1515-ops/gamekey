<?php
session_start();
if (($_SESSION['modulo_acceso'] ?? '') !== 'modulo3') { header('Location: ../../../index.php'); exit; }

require_once "../../config/conexion.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php");
    exit;
}

$idPedido = isset($_POST["id_pedido"])
    ? (int) $_POST["id_pedido"]
    : 0;

$estado = $_POST["estado"] ?? "";

$estadosPermitidos = [
    "Pendiente",
    "Pagado",
    "En preparación",
    "Enviado",
    "Entregado",
    "Cancelado"
];

if (
    $idPedido <= 0 ||
    !in_array($estado, $estadosPermitidos, true)
) {
    die("Los datos enviados no son válidos.");
}

$sql = "
    UPDATE pedidos
    SET estado = ?
    WHERE id_pedido = ?
";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Error al preparar la actualización: " . $conn->error);
}

$stmt->bind_param(
    "si",
    $estado,
    $idPedido
);

if (!$stmt->execute()) {
    die("Error al actualizar el pedido: " . $stmt->error);
}

$stmt->close();

header("Location: index.php?actualizado=1");
exit;