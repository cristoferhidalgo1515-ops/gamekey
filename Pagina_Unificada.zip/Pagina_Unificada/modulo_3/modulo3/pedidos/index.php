<?php
session_start();
if (($_SESSION['modulo_acceso'] ?? '') !== 'modulo3') { header('Location: ../../../index.php'); exit; }

require_once "../../config/conexion.php";

$sql = "SELECT * FROM pedidos ORDER BY fecha_pedido DESC";
$resultado = $conn->query($sql);

if (!$resultado) {
    die("Error al consultar los pedidos: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Pedidos | Gamekey_store</title>

    <link rel="stylesheet" href="../../css/estilos.css">
</head>

<body>

    <header class="encabezado">
        <h1>Gamekey_store</h1>
        <p>Módulo 3 - Gestión de pedidos</p>
    </header>

    <main class="contenedor">

        <div class="titulo-seccion">
            <div>
                <h2>Lista de pedidos</h2>
                <p>Consulta los pedidos registrados en el sistema.</p>
            </div>
        </div>

        <div class="tabla-contenedor">

            <table>

                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Cliente</th>
                        <th>Fecha</th>
                        <th>Total</th>
                        <th>Método de pago</th>
                        <th>Estado</th>
                        <th>Dirección</th>
                        <th>Acciones</th>
                    </tr>
                </thead>

                <tbody>

                    <?php if ($resultado->num_rows > 0): ?>

                        <?php while ($pedido = $resultado->fetch_assoc()): ?>

                            <tr>
                                <td>
                                    <?php echo $pedido["id_pedido"]; ?>
                                </td>

                                <td>
                                    <?php echo htmlspecialchars($pedido["nombre_cliente"]); ?>
                                </td>

                                <td>
                                    <?php echo date(
                                        "d/m/Y H:i",
                                        strtotime($pedido["fecha_pedido"])
                                    ); ?>
                                </td>

                                <td>
                                    $<?php echo number_format($pedido["total"], 2); ?>
                                </td>

                                <td>
                                    <?php echo htmlspecialchars($pedido["metodo_pago"]); ?>
                                </td>

                                <td>
                                    <span class="estado">
                                        <?php echo htmlspecialchars($pedido["estado"]); ?>
                                    </span>
                                </td>

                                <td>
                                    <?php
                                    echo htmlspecialchars(
                                        $pedido["direccion_entrega"] ?? "Sin dirección"
                                    );
                                    ?>
                                </td>


                                
                                <td>
                                    
    <a
        class="boton-editar"
        href="editar_estado.php?id=<?php echo $pedido["id_pedido"]; ?>"
    >
        Cambiar estado
    </a>
</td>
   
                            </tr>

                        <?php endwhile; ?>

                    <?php else: ?>

                        <tr>
                            <td colspan="8" class="sin-datos">
                                No existen pedidos registrados.
                            </td>
                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </main>

</body>

</html>