<?php
session_start();
if (($_SESSION['modulo_acceso'] ?? '') !== 'modulo3') { header('Location: ../../../index.php'); exit; }

require_once "../../config/conexion.php";

if (!isset($_GET["id"]) || !is_numeric($_GET["id"])) {
    die("ID de pedido no válido.");
}

$idPedido = (int) $_GET["id"];

$sql = "SELECT * FROM pedidos WHERE id_pedido = ?";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Error al preparar la consulta: " . $conn->error);
}

$stmt->bind_param("i", $idPedido);
$stmt->execute();

$resultado = $stmt->get_result();
$pedido = $resultado->fetch_assoc();

if (!$pedido) {
    die("El pedido no existe.");
}

$stmt->close();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Cambiar estado | Gamekey Store</title>

    <link rel="stylesheet" href="../../css/estilos.css?v=4">
</head>

<body>

    <header class="encabezado">
        <h1>🎮 GAMEKEY STORE</h1>
        <p>Actualizar estado del pedido</p>
    </header>

    <main class="contenedor">

        <div class="formulario-contenedor">

            <h2>
                Pedido #<?php echo $pedido["id_pedido"]; ?>
            </h2>

            <p class="texto-secundario">
                Cliente:
                <?php echo htmlspecialchars($pedido["nombre_cliente"]); ?>
            </p>

            <form action="actualizar_estado.php" method="POST">

                <input
                    type="hidden"
                    name="id_pedido"
                    value="<?php echo $pedido["id_pedido"]; ?>"
                >

                <div class="grupo-formulario">

                    <label for="estado">
                        Estado del pedido
                    </label>

                    <select id="estado" name="estado" required>

                        <?php
                        $estados = [
                            "Pendiente",
                            "Pagado",
                            "En preparación",
                            "Enviado",
                            "Entregado",
                            "Cancelado"
                        ];
                        ?>

                        <?php foreach ($estados as $estado): ?>

                            <option
                                value="<?php echo $estado; ?>"
                                <?php
                                echo $pedido["estado"] === $estado
                                    ? "selected"
                                    : "";
                                ?>
                            >
                                <?php echo $estado; ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>

                <div class="acciones-formulario">

                    <button type="submit" class="boton-guardar">
                        Guardar cambios
                    </button>

                    <a href="index.php" class="boton-cancelar">
                        Cancelar
                    </a>

                </div>

            </form>

        </div>

    </main>

</body>

</html>