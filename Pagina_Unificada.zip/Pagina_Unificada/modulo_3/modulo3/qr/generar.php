<?php
session_start();
if (($_SESSION['modulo_acceso'] ?? '') !== 'modulo3') { header('Location: ../../../index.php'); exit; }

require_once "../../config/conexion.php";

$sql = "
    SELECT
        dp.id_detalle,
        dp.cantidad,
        p.id_pedido,
        p.nombre_cliente,
        v.titulo,
        v.plataforma
    FROM detalle_pedido AS dp
    INNER JOIN pedidos AS p
        ON dp.id_pedido = p.id_pedido
    INNER JOIN videojuegos AS v
        ON dp.id_videojuego = v.id_videojuego
    ORDER BY dp.id_detalle DESC
";

$resultado = $conn->query($sql);

if (!$resultado) {
    die("Error al consultar los detalles: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Generar QR | Gamekey Store</title>

    <link
        rel="stylesheet"
        href="../../css/estilos.css?v=5"
    >
</head>

<body>

    <header class="encabezado">

        <h1>🎮 GAMEKEY STORE</h1>

        <p>Generar un código QR</p>

    </header>

    <main class="contenedor">

        <div class="formulario-contenedor">

            <h2>Seleccionar producto comprado</h2>

            <p class="texto-secundario">
                El código quedará relacionado con el pedido y
                el videojuego seleccionado.
            </p>

            <form
                action="guardar_qr.php"
                method="POST"
            >

                <div class="grupo-formulario">

                    <label for="id_detalle">
                        Pedido y videojuego
                    </label>

                    <select
                        id="id_detalle"
                        name="id_detalle"
                        required
                    >

                        <option value="">
                            Selecciona una opción
                        </option>

                        <?php while ($detalle = $resultado->fetch_assoc()): ?>

                            <option
                                value="<?php echo $detalle["id_detalle"]; ?>"
                            >
                                Pedido #<?php echo $detalle["id_pedido"]; ?>
                                -
                                <?php
                                echo htmlspecialchars(
                                    $detalle["nombre_cliente"]
                                );
                                ?>
                                -
                                <?php
                                echo htmlspecialchars(
                                    $detalle["titulo"]
                                );
                                ?>
                                (<?php
                                echo htmlspecialchars(
                                    $detalle["plataforma"]
                                );
                                ?>)
                            </option>

                        <?php endwhile; ?>

                    </select>

                </div>

                <div class="acciones-formulario">

                    <button
                        type="submit"
                        class="boton-guardar"
                    >
                        Generar código
                    </button>

                    <a
                        href="index.php"
                        class="boton-cancelar"
                    >
                        Cancelar
                    </a>

                </div>

            </form>

        </div>

    </main>

</body>

</html>