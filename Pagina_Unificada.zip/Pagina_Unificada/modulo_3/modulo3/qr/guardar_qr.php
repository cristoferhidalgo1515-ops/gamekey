<?php
session_start();
if (($_SESSION['modulo_acceso'] ?? '') !== 'modulo3') { header('Location: ../../../index.php'); exit; }

require_once "../../config/conexion.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php");
    exit;
}

$idDetalle = isset($_POST["id_detalle"])
    ? (int) $_POST["id_detalle"]
    : 0;

if ($idDetalle <= 0) {
    die("El detalle seleccionado no es válido.");
}

/*
    Generamos un código difícil de repetir.

    Ejemplo:
    GK-1-4F73A52B91C860D1
*/

try {
    $codigoAleatorio = strtoupper(
        bin2hex(random_bytes(8))
    );
} catch (Exception $error) {
    die("No fue posible generar el código único.");
}

$codigoUnico = "GK-" . $idDetalle . "-" . $codigoAleatorio;

$sql = "
    INSERT INTO codigos_qr
    (
        id_detalle,
        codigo_unico,
        estado
    )
    VALUES (?, ?, 'Activo')
";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Error al preparar el registro: " . $conn->error);
}

$stmt->bind_param(
    "is",
    $idDetalle,
    $codigoUnico
);

if (!$stmt->execute()) {
    die("Error al guardar el código QR: " . $stmt->error);
}

$stmt->close();

header("Location: index.php?generado=1");
exit;