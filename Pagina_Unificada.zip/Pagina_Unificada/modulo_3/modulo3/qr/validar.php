<?php
session_start();
if (($_SESSION['modulo_acceso'] ?? '') !== 'modulo3') { header('Location: ../../../index.php'); exit; }

require_once "../../config/conexion.php";

$codigo = trim($_GET["codigo"] ?? "");

if ($codigo === "") {
    die("No se recibió ningún código QR.");
}

$sql = "
    SELECT
        qr.id_qr,
        qr.codigo_unico,
        qr.estado,
        qr.fecha_generacion,
        qr.fecha_uso,
        p.id_pedido,
        p.nombre_cliente,
        v.titulo,
        v.plataforma
    FROM codigos_qr AS qr
    INNER JOIN detalle_pedido AS dp
        ON qr.id_detalle = dp.id_detalle
    INNER JOIN pedidos AS p
        ON dp.id_pedido = p.id_pedido
    INNER JOIN videojuegos AS v
        ON dp.id_videojuego = v.id_videojuego
    WHERE qr.codigo_unico = ?
";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Error al preparar la consulta: " . $conn->error);
}

$stmt->bind_param("s", $codigo);
$stmt->execute();

$resultado = $stmt->get_result();
$qr = $resultado->fetch_assoc();

$stmt->close();

$valido = $qr !== null;
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Validar QR | Gamekey Store</title>

    <link
        rel="stylesheet"
        href="../../css/estilos.css?v=6"
    >
</head>

<body>

    <header class="encabezado">
        <h1>🎮 GAMEKEY STORE</h1>
        <p>Validación del código QR</p>
    </header>

    <main class="contenedor">

        <?php if (!$valido): ?>

            <section class="resultado-validacion resultado-error">

                <h2>QR no válido</h2>

                <p>
                    El código escaneado no está registrado
                    en el sistema.
                </p>

            </section>

        <?php else: ?>

            <?php
            $claseResultado = $qr["estado"] === "Activo"
                ? "resultado-correcto"
                : "resultado-advertencia";
            ?>

            <section
                class="resultado-validacion <?php echo $claseResultado; ?>"
            >

                <?php if ($qr["estado"] === "Activo"): ?>

                    <h2>QR válido y activo</h2>

                    <p>
                        Este código pertenece a una compra registrada.
                    </p>

                <?php elseif ($qr["estado"] === "Utilizado"): ?>

                    <h2>QR utilizado anteriormente</h2>

                    <p>
                        Este código ya no puede utilizarse nuevamente.
                    </p>

                <?php else: ?>

                    <h2>QR anulado</h2>

                    <p>
                        Este código fue anulado y no puede utilizarse.
                    </p>

                <?php endif; ?>

                <div class="datos-validacion">

                    <p>
                        <strong>Pedido:</strong>
                        #<?php echo $qr["id_pedido"]; ?>
                    </p>

                    <p>
                        <strong>Cliente:</strong>

                        <?php
                        echo htmlspecialchars($qr["nombre_cliente"]);
                        ?>
                    </p>

                    <p>
                        <strong>Videojuego:</strong>

                        <?php echo htmlspecialchars($qr["titulo"]); ?>
                    </p>

                    <p>
                        <strong>Plataforma:</strong>

                        <?php echo htmlspecialchars($qr["plataforma"]); ?>
                    </p>

                    <p>
                        <strong>Estado:</strong>

                        <?php echo htmlspecialchars($qr["estado"]); ?>
                    </p>

                </div>

            </section>

        <?php endif; ?>

    </main>

</body>

</html>