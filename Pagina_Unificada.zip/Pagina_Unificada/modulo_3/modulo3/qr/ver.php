<?php
session_start();
if (($_SESSION['modulo_acceso'] ?? '') !== 'modulo3') { header('Location: ../../../index.php'); exit; }

require_once "../../config/conexion.php";

if (!isset($_GET["id"]) || !is_numeric($_GET["id"])) {
    die("ID de código QR no válido.");
}

$idQR = (int) $_GET["id"];

$sql = "
    SELECT
        qr.id_qr,
        qr.codigo_unico,
        qr.fecha_generacion,
        qr.estado,
        qr.fecha_uso,
        p.id_pedido,
        p.nombre_cliente,
        v.titulo,
        v.plataforma
    FROM codigos_qr AS qr
    INNER JOIN detalle_pedido AS dp
        ON qr.id_detalle = dp.id_detalle
    INNER JOIN pedidos AS p
        ON dp.id_pedido = p.id_pedido
    INNER JOIN videojuegos AS v
        ON dp.id_videojuego = v.id_videojuego
    WHERE qr.id_qr = ?
";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Error al preparar la consulta: " . $conn->error);
}

$stmt->bind_param("i", $idQR);
$stmt->execute();

$resultado = $stmt->get_result();
$qr = $resultado->fetch_assoc();

$stmt->close();

if (!$qr) {
    die("El código QR no existe.");
}

/*
    Esta será la dirección guardada dentro del QR.

    Cuando alguien lo escanee, abrirá la página de validación.
*/
$protocolo = isset($_SERVER["HTTPS"]) && $_SERVER["HTTPS"] === "on"
    ? "https"
    : "http";

$servidor = $_SERVER["HTTP_HOST"];

$rutaProyecto = "/modulo_3/modulo3/qr/validar.php";

$urlValidacion = $protocolo
    . "://"
    . $servidor
    . $rutaProyecto
    . "?codigo="
    . urlencode($qr["codigo_unico"]);
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Ver código QR | Gamekey Store</title>

    <link
        rel="stylesheet"
        href="../../css/estilos.css?v=6"
    >
</head>

<body>

    <header class="encabezado">
        <h1>🎮 GAMEKEY STORE</h1>
        <p>Código QR de la compra</p>
    </header>

    <main class="contenedor">

        <section class="qr-tarjeta">

            <div>

                <h2>
                    Pedido #<?php echo $qr["id_pedido"]; ?>
                </h2>

                <p>
                    <strong>Cliente:</strong>

                    <?php
                    echo htmlspecialchars($qr["nombre_cliente"]);
                    ?>
                </p>

                <p>
                    <strong>Videojuego:</strong>

                    <?php echo htmlspecialchars($qr["titulo"]); ?>
                </p>

                <p>
                    <strong>Plataforma:</strong>

                    <?php echo htmlspecialchars($qr["plataforma"]); ?>
                </p>

                <p>
                    <strong>Estado:</strong>

                    <span class="estado">
                        <?php echo htmlspecialchars($qr["estado"]); ?>
                    </span>
                </p>

                <p>
                    <strong>Código:</strong>
                </p>

                <p class="codigo-completo">
                    <?php
                    echo htmlspecialchars($qr["codigo_unico"]);
                    ?>
                </p>

            </div>

            <div class="qr-visual">

                <div id="codigoQR"></div>

                <p>
                    Escanea para validar la compra.
                </p>

            </div>

        </section>

        <div class="acciones-formulario">

            <?php if ($qr["estado"] === "Activo"): ?>

                <form
                    action="marcar_utilizado.php"
                    method="POST"
                    onsubmit="return confirm(
                        '¿Deseas marcar este QR como utilizado?'
                    );"
                >

                    <input
                        type="hidden"
                        name="id_qr"
                        value="<?php echo $qr["id_qr"]; ?>"
                    >

                    <button
                        type="submit"
                        class="boton-guardar"
                    >
                        Marcar como utilizado
                    </button>

                </form>

            <?php endif; ?>

            <a href="index.php" class="boton-cancelar">
                Volver
            </a>

        </div>

    </main>

    <script
        src="https://cdn.jsdelivr.net/gh/davidshimjs/qrcodejs/qrcode.min.js"
    ></script>

    <script>
        const contenidoQR = <?php echo json_encode($urlValidacion); ?>;

        new QRCode(
            document.getElementById("codigoQR"),
            {
                text: contenidoQR,
                width: 230,
                height: 230,
                correctLevel: QRCode.CorrectLevel.H
            }
        );
    </script>

</body>

</html>