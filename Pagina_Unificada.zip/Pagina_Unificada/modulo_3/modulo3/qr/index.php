<?php
session_start();
if (($_SESSION['modulo_acceso'] ?? '') !== 'modulo3') { header('Location: ../../../index.php'); exit; }

require_once "../../config/conexion.php";

$sql = "
    SELECT
        dq.id_qr,
        dq.codigo_unico,
        dq.fecha_generacion,
        dq.estado,
        dq.fecha_uso,
        dp.id_detalle,
        p.id_pedido,
        p.nombre_cliente,
        v.titulo,
        v.plataforma
    FROM codigos_qr AS dq
    INNER JOIN detalle_pedido AS dp
        ON dq.id_detalle = dp.id_detalle
    INNER JOIN pedidos AS p
        ON dp.id_pedido = p.id_pedido
    INNER JOIN videojuegos AS v
        ON dp.id_videojuego = v.id_videojuego
    ORDER BY dq.id_qr DESC
";

$resultado = $conn->query($sql);

if (!$resultado) {
    die("Error al consultar los códigos QR: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Códigos QR | Gamekey Store</title>

    <link
        rel="stylesheet"
        href="../../css/estilos.css?v=5"
    >
</head>

<body>

    <header class="encabezado">

        <h1>🎮 GAMEKEY STORE</h1>

        <p>Gestión de códigos QR</p>

    </header>

    <main class="contenedor">

        <div class="titulo-seccion">

            <div>
                <h2>Códigos QR</h2>

                <p>
                    Consulta los códigos generados para los pedidos.
                </p>
            </div>

            <div class="acciones-superiores">

                <a
                    href="generar.php"
                    class="boton-guardar"
                >
                    Generar QR
                </a>

                <a
                    href="../dashboard.php"
                    class="boton-volver"
                >
                    Volver al dashboard
                </a>

            </div>

        </div>

        <?php if (isset($_GET["generado"])): ?>

            <div class="mensaje-exito">
                Código QR generado correctamente.
            </div>

        <?php endif; ?>

        <div class="tabla-contenedor">

            <table>

                <thead>

                    <tr>
                        <th>ID</th>
                        <th>Pedido</th>
                        <th>Cliente</th>
                        <th>Videojuego</th>
                        <th>Código único</th>
                        <th>Fecha</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>

                </thead>

                <tbody>

                    <?php if ($resultado->num_rows > 0): ?>

                        <?php while ($qr = $resultado->fetch_assoc()): ?>

                            <tr>

                                <td>
                                    <?php echo $qr["id_qr"]; ?>
                                </td>

                                <td>
                                    #<?php echo $qr["id_pedido"]; ?>
                                </td>

                                <td>
                                    <?php
                                    echo htmlspecialchars(
                                        $qr["nombre_cliente"]
                                    );
                                    ?>
                                </td>

                                <td>
                                    <?php
                                    echo htmlspecialchars($qr["titulo"]);
                                    ?>

                                    <br>

                                    <small>
                                        <?php
                                        echo htmlspecialchars(
                                            $qr["plataforma"]
                                        );
                                        ?>
                                    </small>
                                </td>

                                <td class="codigo-unico">
                                    <?php
                                    echo htmlspecialchars(
                                        $qr["codigo_unico"]
                                    );
                                    ?>
                                </td>

                                <td>
                                    <?php
                                    echo date(
                                        "d/m/Y H:i",
                                        strtotime($qr["fecha_generacion"])
                                    );
                                    ?>
                                </td>

                                <td>
                                    <span class="estado">
                                        <?php
                                        echo htmlspecialchars(
                                            $qr["estado"]
                                        );
                                        ?>
                                    </span>
                                </td>

                                <td>

                                    <a
                                        class="boton-editar"
                                        href="ver.php?id=<?php echo $qr["id_qr"]; ?>"
                                    >
                                        Ver QR
                                    </a>

                                </td>

                            </tr>

                        <?php endwhile; ?>

                    <?php else: ?>

                        <tr>

                            <td colspan="8" class="sin-datos">

                                Todavía no se han generado códigos QR.

                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </main>

</body>

</html>