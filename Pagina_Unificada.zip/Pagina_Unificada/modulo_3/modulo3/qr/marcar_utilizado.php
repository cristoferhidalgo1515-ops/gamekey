<?php
session_start();
if (($_SESSION['modulo_acceso'] ?? '') !== 'modulo3') { header('Location: ../../../index.php'); exit; }

require_once "../../config/conexion.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php");
    exit;
}

$idQR = isset($_POST["id_qr"])
    ? (int) $_POST["id_qr"]
    : 0;

if ($idQR <= 0) {
    die("ID de QR no válido.");
}

/*
    Solo se puede modificar si todavía está activo.
    Así evitamos reutilizarlo.
*/
$sql = "
    UPDATE codigos_qr
    SET
        estado = 'Utilizado',
        fecha_uso = NOW()
    WHERE id_qr = ?
      AND estado = 'Activo'
";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Error al preparar la actualización: " . $conn->error);
}

$stmt->bind_param("i", $idQR);

if (!$stmt->execute()) {
    die("Error al actualizar el código QR: " . $stmt->error);
}

$filasModificadas = $stmt->affected_rows;

$stmt->close();

if ($filasModificadas === 0) {
    die("El código ya fue utilizado, anulado o no existe.");
}

header("Location: ver.php?id=" . $idQR . "&utilizado=1");
exit;