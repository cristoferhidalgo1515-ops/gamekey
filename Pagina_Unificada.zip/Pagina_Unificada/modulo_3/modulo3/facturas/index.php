<?php
session_start();
if (($_SESSION['modulo_acceso'] ?? '') !== 'modulo3') { header('Location: ../../../index.php'); exit; }

require_once "../../config/conexion.php";

$sql = "
    SELECT
        f.id_factura,
        f.numero_factura,
        f.fecha_emision,
        f.subtotal,
        f.impuesto,
        f.total,
        p.id_pedido,
        p.nombre_cliente,
        p.estado AS estado_pedido
    FROM facturas AS f
    INNER JOIN pedidos AS p
        ON f.id_pedido = p.id_pedido
    ORDER BY f.id_factura DESC
";

$resultado = $conn->query($sql);

if (!$resultado) {
    die("Error al consultar las facturas: " . $conn->error);
}
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>Facturas | Gamekey Store</title>

    <link
        rel="stylesheet"
        href="../../css/estilos.css?v=7"
    >
</head>

<body>

    <header class="encabezado">
        <h1>🎮 GAMEKEY STORE</h1>
        <p>Gestión de facturas</p>
    </header>

    <main class="contenedor">

        <div class="titulo-seccion">

            <div>
                <h2>Facturas</h2>

                <p>
                    Consulta y descarga los comprobantes generados.
                </p>
            </div>

            <div class="acciones-superiores">

                <a
                    href="generar.php"
                    class="boton-guardar"
                >
                    Generar factura
                </a>

                <a
                    href="../dashboard.php"
                    class="boton-volver"
                >
                    Volver al dashboard
                </a>

            </div>

        </div>

        <?php if (isset($_GET["generada"])): ?>

            <div class="mensaje-exito">
                Factura generada correctamente.
            </div>

        <?php endif; ?>

        <div class="tabla-contenedor">

            <table>

                <thead>

                    <tr>
                        <th>ID</th>
                        <th>Número</th>
                        <th>Pedido</th>
                        <th>Cliente</th>
                        <th>Fecha</th>
                        <th>Subtotal</th>
                        <th>IVA</th>
                        <th>Total</th>
                        <th>Acciones</th>
                    </tr>

                </thead>

                <tbody>

                    <?php if ($resultado->num_rows > 0): ?>

                        <?php while ($factura = $resultado->fetch_assoc()): ?>

                            <tr>

                                <td>
                                    <?php echo $factura["id_factura"]; ?>
                                </td>

                                <td>
                                    <?php
                                    echo htmlspecialchars(
                                        $factura["numero_factura"]
                                    );
                                    ?>
                                </td>

                                <td>
                                    #<?php echo $factura["id_pedido"]; ?>
                                </td>

                                <td>
                                    <?php
                                    echo htmlspecialchars(
                                        $factura["nombre_cliente"]
                                    );
                                    ?>
                                </td>

                                <td>
                                    <?php
                                    echo date(
                                        "d/m/Y H:i",
                                        strtotime($factura["fecha_emision"])
                                    );
                                    ?>
                                </td>

                                <td>
                                    $<?php
                                    echo number_format(
                                        $factura["subtotal"],
                                        2
                                    );
                                    ?>
                                </td>

                                <td>
                                    $<?php
                                    echo number_format(
                                        $factura["impuesto"],
                                        2
                                    );
                                    ?>
                                </td>

                                <td>
                                    <strong>
                                        $<?php
                                        echo number_format(
                                            $factura["total"],
                                            2
                                        );
                                        ?>
                                    </strong>
                                </td>

                                <td>

                                    <a
                                        class="boton-editar"
                                        href="ver.php?id=<?php echo $factura["id_factura"]; ?>"
                                    >
                                        Ver
                                    </a>

                                    <a
                                        class="boton-guardar"
                                        href="descargar_pdf.php?id=<?php echo $factura["id_factura"]; ?>"
                                    >
                                        PDF
                                    </a>

                                </td>

                            </tr>

                        <?php endwhile; ?>

                    <?php else: ?>

                        <tr>

                            <td colspan="9" class="sin-datos">
                                Todavía no existen facturas.
                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </main>

</body>

</html>