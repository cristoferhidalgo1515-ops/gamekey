<?php
session_start();
if (($_SESSION['modulo_acceso'] ?? '') !== 'modulo3') { header('Location: ../../../index.php'); exit; }

require_once "../../config/conexion.php";

if (!isset($_GET["id"]) || !is_numeric($_GET["id"])) {
    die("ID de factura no válido.");
}

$idFactura = (int) $_GET["id"];

/* Consultar datos generales de la factura */

$sqlFactura = "
    SELECT
        f.id_factura,
        f.numero_factura,
        f.fecha_emision,
        f.subtotal,
        f.impuesto,
        f.total,
        p.id_pedido,
        p.nombre_cliente,
        p.metodo_pago,
        p.direccion_entrega,
        p.estado AS estado_pedido
    FROM facturas AS f
    INNER JOIN pedidos AS p
        ON f.id_pedido = p.id_pedido
    WHERE f.id_factura = ?
";

$stmtFactura = $conn->prepare($sqlFactura);

if (!$stmtFactura) {
    die("Error al preparar la factura: " . $conn->error);
}

$stmtFactura->bind_param("i", $idFactura);
$stmtFactura->execute();

$resultadoFactura = $stmtFactura->get_result();
$factura = $resultadoFactura->fetch_assoc();

$stmtFactura->close();

if (!$factura) {
    die("La factura solicitada no existe.");
}

/* Consultar los videojuegos del pedido */

$sqlDetalles = "
    SELECT
        v.titulo,
        v.plataforma,
        dp.cantidad,
        dp.precio_unitario,
        dp.subtotal
    FROM detalle_pedido AS dp
    INNER JOIN videojuegos AS v
        ON dp.id_videojuego = v.id_videojuego
    WHERE dp.id_pedido = ?
    ORDER BY dp.id_detalle ASC
";

$stmtDetalles = $conn->prepare($sqlDetalles);

if (!$stmtDetalles) {
    die("Error al consultar los productos: " . $conn->error);
}

$stmtDetalles->bind_param("i", $factura["id_pedido"]);
$stmtDetalles->execute();

$detalles = $stmtDetalles->get_result();
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        <?php echo htmlspecialchars($factura["numero_factura"]); ?>
    </title>

    <link
        rel="stylesheet"
        href="../../css/estilos.css?v=8"
    >
</head>

<body>

    <header class="encabezado">
        <h1>🎮 GAMEKEY STORE</h1>
        <p>Comprobante de compra</p>
    </header>

    <main class="contenedor">

        <section class="factura-documento">

            <div class="factura-cabecera">

                <div>
                    <h2>GAMEKEY STORE</h2>
                    <p>Tienda de videojuegos</p>
                    <p>El Salvador</p>
                </div>

                <div class="factura-numero">
                    <h3>FACTURA</h3>

                    <p>
                        <?php
                        echo htmlspecialchars(
                            $factura["numero_factura"]
                        );
                        ?>
                    </p>
                </div>

            </div>

            <hr>

            <div class="factura-informacion">

                <div>
                    <p>
                        <strong>Cliente:</strong>

                        <?php
                        echo htmlspecialchars(
                            $factura["nombre_cliente"]
                        );
                        ?>
                    </p>

                    <p>
                        <strong>Dirección:</strong>

                        <?php
                        echo htmlspecialchars(
                            $factura["direccion_entrega"]
                            ?: "No registrada"
                        );
                        ?>
                    </p>

                    <p>
                        <strong>Método de pago:</strong>

                        <?php
                        echo htmlspecialchars(
                            $factura["metodo_pago"]
                        );
                        ?>
                    </p>
                </div>

                <div>
                    <p>
                        <strong>Pedido:</strong>
                        #<?php echo $factura["id_pedido"]; ?>
                    </p>

                    <p>
                        <strong>Fecha:</strong>

                        <?php
                        echo date(
                            "d/m/Y H:i",
                            strtotime($factura["fecha_emision"])
                        );
                        ?>
                    </p>

                    <p>
                        <strong>Estado:</strong>

                        <?php
                        echo htmlspecialchars(
                            $factura["estado_pedido"]
                        );
                        ?>
                    </p>
                </div>

            </div>

            <div class="tabla-factura">

                <table>

                    <thead>
                        <tr>
                            <th>Videojuego</th>
                            <th>Plataforma</th>
                            <th>Cantidad</th>
                            <th>Precio</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php if ($detalles->num_rows > 0): ?>

                            <?php while ($detalle = $detalles->fetch_assoc()): ?>

                                <tr>
                                    <td>
                                        <?php
                                        echo htmlspecialchars(
                                            $detalle["titulo"]
                                        );
                                        ?>
                                    </td>

                                    <td>
                                        <?php
                                        echo htmlspecialchars(
                                            $detalle["plataforma"]
                                        );
                                        ?>
                                    </td>

                                    <td>
                                        <?php echo $detalle["cantidad"]; ?>
                                    </td>

                                    <td>
                                        $<?php
                                        echo number_format(
                                            $detalle["precio_unitario"],
                                            2
                                        );
                                        ?>
                                    </td>

                                    <td>
                                        $<?php
                                        echo number_format(
                                            $detalle["subtotal"],
                                            2
                                        );
                                        ?>
                                    </td>
                                </tr>

                            <?php endwhile; ?>

                        <?php else: ?>

                            <tr>
                                <td colspan="5">
                                    No hay productos en este pedido.
                                </td>
                            </tr>

                        <?php endif; ?>

                    </tbody>

                </table>

            </div>

            <div class="factura-totales">

                <p>
                    <span>Subtotal:</span>

                    <strong>
                        $<?php
                        echo number_format($factura["subtotal"], 2);
                        ?>
                    </strong>
                </p>

                <p>
                    <span>IVA:</span>

                    <strong>
                        $<?php
                        echo number_format($factura["impuesto"], 2);
                        ?>
                    </strong>
                </p>

                <p class="factura-total-final">
                    <span>Total:</span>

                    <strong>
                        $<?php
                        echo number_format($factura["total"], 2);
                        ?>
                    </strong>
                </p>

            </div>

            <div class="factura-pie">
                <p>Gracias por comprar en Gamekey Store.</p>
            </div>

        </section>

        <div class="acciones-formulario">

            <a
                href="descargar_pdf.php?id=<?php echo $factura["id_factura"]; ?>"
                class="boton-guardar"
            >
                Descargar PDF
            </a>

            <a href="index.php" class="boton-cancelar">
                Volver
            </a>

        </div>

    </main>

</body>

</html>

<?php
$stmtDetalles->close();
?>