<?php
session_start();
if (($_SESSION['modulo_acceso'] ?? '') !== 'modulo3') { header('Location: ../index.php'); exit; }


require_once "config/conexion.php";

echo "<h1>Pixel Play</h1>";
echo "<h2>Prueba de conexión</h2>";
echo "<p>La conexión con la base de datos funciona correctamente.</p>";

?>