<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pixel Play - Módulo 3</title>
</head>
<body>

    <h1>Pixel Play</h1>
    <h2>Módulo 3: pedidos, inventario, QR y facturas</h2>

    <?php
        echo "<p>PHP está funcionando correctamente.</p>";
    ?>

</body>
</html>